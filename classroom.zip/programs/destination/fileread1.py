
'''
# read operation

# fobj acts as file cursor or file pointer or file reference  or handler
# fobj always checks for EOF
with open("languages.txt","r") as fr:
    for line in fr:
        line = line.strip()  # remove whitespaces if any
        print(line)




# using readlines()
with open('languages.txt','r') as fread:
    print(fread.readlines())



# using readlines() - reading line by line
with open('languages.txt','r') as fread:
    for line in fread.readlines():
        print(line)

'''

# using read() - file content will be displayed all at once

with open('languages.txt','r') as fobj:
    print(fobj.read(20))
