

book  =  {"chap1":10 , "chap2":20 ,"chap3":30}

print(book)

# access individual value
print(book["chap1"]) # 10
print(book["chap2"]) # 20
#print(book['chap100'])

if "chap100" in book:
    print(book["chap100"])
else:
    print("key doesnt exist")


# add new key:value pairs
book["chap4"] = 40
book["chap5"] = 50
print("After adding :" , book)


print(book)

print("Only keys :", book.keys())

print("Only values :", book.values())

print("items :", book.items())

#print(book["chap100"])
print(book.get("chap1"))  # If key not existing.. it will return None


book.pop('chap1')
print('After removing :', book)

book.popitem()
print('After removing :', book)

book.popitem()
print('After removing :', book)



newbook = {"chap11":110 , "chap12":120}
book.update(newbook)

print("After updating :", book)


#### looping ####

# dipsplay keys
for key in book.keys():
    print(key)


# display values
for value in book.values():
    print(value)

# display key:value
for key,value in book.items():
    print(key,value)
    










































