
with open("languages.txt") as fobj:
    for line in fobj:
        line = line.split(",")
        print(line)






############################
#using csv library
############################
import csv
filename = input('Enter any filename :')
with open(filename) as fobj:
    # converting file object to csv understandable object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)

