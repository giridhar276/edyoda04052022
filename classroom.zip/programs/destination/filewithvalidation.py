





import csv
import os
import logging
filename = "langinfo.csv"

path = "D:\\new\\new"

if os.path.isdir(path):
    os.chdir(path)
    if os.path.isfile(filename) and os.path.getsize(filename) > 0 :
        try:
            with open(filename) as fobj:
                # converting file object to csv understandable object
                reader = csv.reader(fobj)
                for line in reader:
                    print(line)
        except Exception as err:
            print(err)
    else:
        print("File doesn't exist OR file is empty")

else:
    print(path,"doesn't exist")
