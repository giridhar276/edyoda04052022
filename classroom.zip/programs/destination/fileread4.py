

import sys

try:
    filename = input("Enter any filename:")
    with open(filename,"r") as fobj:
        for line in fo:
            line = line.strip()
            print(line)
    #val = 2 + "helo"
    print(data)

except FileNotFoundError  as err:
    print(err)
    print("file is not available..please check")
except TypeError as err:
    print(err)
    print("Invalid operation")
except (NameError,KeyError,IndexError) as err:
    print(err)
    print(sys.exit(1))
except Exception as err:
    print(err)
    print(sys.exc_info())


print("regular program")
