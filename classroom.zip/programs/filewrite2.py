# write mode
fobj = open("customers.txt","w")

fobj.write('tcs\n')
fobj.write('wipro\n')

fobj.close()



# write mode
fw = open("numbers.txt","w")


for val in range(1,100):
    #print(val)
    fw.write(str(val) + "\n")

fw.close()



