
# default args

def display(a = 0,b = 0,c = 0,d = 0):
    print(a,b,c,d)

display()          # 0 0 0 0
display(10)        # 10 0 0 0
display(10,20)
display(10,20,30)
display(10,20,30,40)

