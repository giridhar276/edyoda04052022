



import os


for file in os.listdir():
    print(file.ljust(20), os.path.getsize(file),"bytes")
