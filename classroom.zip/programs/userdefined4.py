

# keyword arguments


def display(c,a,b):
    print(a,b,c)


a = 10
b  = 20
c = 30
display( a = 10 , b = 20 ,c = 30)
