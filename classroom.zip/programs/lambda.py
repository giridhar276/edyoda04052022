




def display(a,b):
    c  = a + b
    return c


output = display(10,20)
print(output)



## lambda functions
## inline functions
## nameless function
## lambda is the replacement of the single liner function
## Advantage : Instead of calling function body.. lambda will be replaced in the function call

# functionname = lambda variables :expression



display = lambda a,b : a + b


output = display(10,20)
print(output)


