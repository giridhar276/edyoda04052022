# write a program to append 5 to each element in the list
alist = [10,20,30]
#[15,25,35]

blist = []
for val in alist:
    blist.append(val + 5)
print(blist)



# map(function, iterable)
#method1
alist = [10,20,30]
def increment(x):
    return x + 5
print(list(map(increment,alist)))


# map(function, iterable)
#method2
alist = [10,20,30]
increment = lambda x : x +5
print(list(map(increment,alist)))



# map(function, iterable)
#method3
alist = [10,20,30]
print(list(map(lambda x : x +5,alist)))



alist = [12,3,4,5,56,43]
print(list(filter(lambda x : x % 2,alist)))

print(list(filter(lambda x : x % 2 == 0 ,alist)))



elements = ["unix","linux","java","perl","c","spark"]

#["unix","java","perl"]

print(list(filter(lambda x : len(x) == 4 ,elements)))



























