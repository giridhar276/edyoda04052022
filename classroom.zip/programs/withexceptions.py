filename = input("Enter any filename:")
with open(filename,"r") as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
print("---")
