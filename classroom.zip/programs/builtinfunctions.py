

# capture input from keyboard
# python2.x :  raw_input()

name = input("Enter any string :")
print("you entered :", name)


value = input("Enter any value:")

output = 100 + int(value)
print("Final output :", output)





print(list(range(1,100)))


val = 10
print(type(val))

print(isinstance(val,int))   # True


alist = [10,20,30,40]
print(sum(alist))


print(max(alist))

print(min(alist))
      

