
### fixed arguments


# function body
def display(a,b,c):
    print(a,b)




#calling function
display(10,20)
