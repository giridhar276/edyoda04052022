


import os

filelist = []
dirlist = []

for file in os.listdir():
    if os.path.isfile(file):
        filelist.append(file)
    else:
        dirlist.append(file)

print("**** FILES *****")
for file in filelist:
    print(file)
print("Total no. of files :", len(filelist))
print("***** directories ****")
for file in dirlist:
    print(file)

print("Total no. of directories :",len(dirlist))

