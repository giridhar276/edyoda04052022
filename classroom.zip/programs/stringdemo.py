

print(10,20,30)

val = 10
print("Value is", val)

language = "python programming"
print("I love", language)

# string slicing
name = "python programming"

# string[start:stop:step])
print(name[0])  # p
print(name[1])  # y
print(name[0:4]) #pyth

print(name[-1])  #g
print(name[::])  #python programming
print(name[:])   #python programming

print(name[0:18:2])  #pto rgamn
print(name[1:18:2])  #yhnpormig
print(name[4:18:5])  #oom

           
print(name[5])
print(name[1:])

print(name[1::6])




name = "python programming"


print(name.upper())
print(name.lower())

print(name.capitalize())
print(name.title())

print(name.split(" "))  # converting string to split

print(name.replace("python","unix"))

print(name.center(40))
print(name.center(40,"*"))


print(name.startswith("z"))
print(name.startswith("p"))
print(name.endswith("m"))
print(name.endswith("g"))


aname = " python "
print(len(aname))
print(len(aname.strip()))
print(len(aname.lstrip()))
print(len(aname.rstrip()))


print(name.find("python"))
print(name.find("asfasf"))




print(name)
print(name.isupper())
print(name.islower())


a,b = 10,5


if a < b :
    print("A is less than B")
    print("Inside if")
    print("Still inside if")
else :
    print("A is greater than B")
    print("Inside else")
    print("Still inside else")

print("regular program")




if name.isupper():
    print("Yes... string is upper")
elif name.islower():
    print("String is lower")
elif name.isdigit():
    print("String has digit")
else:
    print("its something else")



for val in range(1,11):
    print(val)

print("----")
# range(start,stop,step)
for val in range(1,11,2):
    print(val)

print("----")
for val in range(10,1,-2):
    print(val)


print("----")
name = "python"

for char in name:
    print("Character is :", char)





    




















































