


alist = [10,20,30]

if 10 in alist:
    print('something')



book = {"chap1":10 ,"chap2":20}

if "chap1" in book:
    print('do something')



alist = [10,20,30]
for val in alist:
    print(val)
