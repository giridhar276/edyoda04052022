

alist = [45,32,450,3,56,3,5,67]

print(alist)

print(alist[::2])
print(alist[0:5:3])


# list methods

# adding single value
alist.append(30)
print("After appending :", alist)

# adding multiple values
alist.extend([98,76])
print("After extending :", alist)


# list.insert(index,value)
alist.insert(2,4000)
print('after inserting :', alist)


# alist.pop(index)  : removes based on the index
alist.pop(2)   # 2 is the index
print('After pop:', alist)

# alist.remove(value)
alist.remove(3)
print('After remove :', alist)


# list.count() : no. of times particualar elements has been repeated
getcount = alist.count(45)
print(getcount)


# reverse all the elements in the list in place
alist.reverse()
print("After reversing :", alist)


# sort the values
alist.sort()
print(alist)


# sort the values
print("reserve sorted order")
alist.sort(reverse = True)
print(alist)



alist = [45,32,450,3,56,3,5,67]


# to check for existence 
if 45 in alist:
    print("45 exists")
else:
    print("45 doesn't exist")



getcount = alist.count(45)
if getcount > 0 :
    print("45 exists")





print(" reading values")
alist = [45,32,450,3,56,3,5,67]
for val in alist:
    print(val)




print("*** with index ****")
alist = [45,32,450,3,56,3,5,67]
for val in range(0,len(alist)):
    print(alist[val])







































