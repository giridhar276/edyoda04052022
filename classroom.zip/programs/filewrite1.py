

# creating file in different path
# write mode
fw = open("D:\\new\\new\\numbers.txt","w")
#fw = open(r"D:\new\new\numbers.txt","w")   # raw string
#fw = open("D:/new/new/numbers.txt","w")


for val in range(1,100):
    #print(val)
    fw.write(str(val) + "\n")

fw.close()
