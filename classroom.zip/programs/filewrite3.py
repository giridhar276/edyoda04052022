


# traditional way or regular way
# write mode
fobj = open("customers.txt","w")

fobj.write('tcs\n')
fobj.write('wipro\n')

fobj.close()




# context manager
# using context manager.. it is not required to close the file
# file gets closed automatically

with open("customers.txt","w") as fobj:
    fobj.write('tcs\n')
    fobj.write('wipro\n')


