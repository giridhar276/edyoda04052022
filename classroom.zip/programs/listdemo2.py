


alist = [10,20,30,40,50]


alist[0] = 100
print("After replacing:", alist)





print("************ tuple *************")
atup = (45,3,45,32,64)
#atup[0] = 10000
#print("After replacing :", alist)



#typecasting  - converting from one object to another object

atup = (45,3,45,32,64)
# converting to list
alist = list(atup)
alist.append(100)
# recoverting back to tuple
atup = tuple(alist)
print(atup)
                                      
