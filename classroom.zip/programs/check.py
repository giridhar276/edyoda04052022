
import os

alist = []
blist = []    
for file in os.listdir("C:\\data"):
    if os.path.isdir(file):                           
        alist.append(file)
    else :
        blist.append(file)

print("files")
for f in alist:
    print(f)
print("Total no of files :",len(blist))
print("Dirs")

for d in blist:
    print(d)
print("Total no of dirs :",len(alist))
