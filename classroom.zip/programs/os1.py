


# write a program to display all the files from the current directory


import os

try:
    for file in os.listdir():
        #print(file)
        if file.endswith(".csv"):
            print(file)
except Exception as err:
    print(err)




