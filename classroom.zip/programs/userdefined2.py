
'''

### variable length arguments


# function body
def display(*args):
    print(type(args))
    for val in args:
        print(val)


#calling function
display(10,20,30,40,50)
'''






def displayvalues(**kwargs):
    #print(kwargs)
    for key,value in kwargs.items():
        print(key,value)



displayvalues(chap1 = 10 , chap2 = 20)
