
#method 1: all the methods will be imported to your space
import math
print(math.log(2))
print(math.tan(1))


#method 2: importing with alias
import math as m
print(m.cos(1))
print(m.floor(12.2))


#method3
from math import ceil,log,tan
print(ceil(223.3))
print(log(3))
print(tan(2))

