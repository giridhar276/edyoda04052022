
'''
with open("language.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if 'python' in line  or 'pytttthon' in line  or 'pytttttttthon' in line or 'pyhon' in line:
            print(line)
'''


import re
with open("language.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("python",line):
            print(line)
