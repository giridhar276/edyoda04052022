
import shutil
import os

source = r"D:\trainings\edyoda04052022\programs\source"

destination = r"D:\trainings\edyoda04052022\programs\destination"
#destination = "D:\\trainings\\edyoda04052022\\programs\\destination"
#destination = "D:/trainings/edyoda04052022/programs/destination"



for file in os.listdir(source):
    shutil.copy(source + "\\" +  file,destination)


