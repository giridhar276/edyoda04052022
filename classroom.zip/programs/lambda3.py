

square = lambda x : x * x if ( x > 0 ) else None



